def add(val1,val2):
    try:
        result=val1+val2
        return result
    except:
        return "invalid input"   #here we wrie same thing which is writen in the test file.

def sub(val1,val2):
    return val1-val2

def mul(val1,val2):
    return val1*val2

def div(val1,val2):
    return val1/val2
